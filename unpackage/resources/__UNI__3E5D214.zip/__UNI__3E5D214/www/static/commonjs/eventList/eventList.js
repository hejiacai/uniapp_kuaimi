/*
*事件常用字段 防止全局污染 v1.0
*/

export default {
	GO_TO_JOBDETAIL: 'gotoJobDetail', //跳转到职位详情
}
